import React from 'react';
import '../css/cards.css';
import BotonComprar from './BotonComprar';
import {Divider}  from 'semantic-ui-react';
import limpiadorFacialconFormaPulpo from '../image/img-koukla/limpiadorFacial-conFormaPulpo.jpg'
import paletaSombras from '../image/img-koukla/paletaSombras.PNG'
import mascara2en1 from '../image/img-koukla/mascara2en1.PNG'
import fijadorMaquillaje from '../image/img-koukla/fijadorMaquillaje.PNG';

import {
    Link
    } from 'react-router-dom';


function Cards(){
    return(
    <div className='cardsNovedades'>
        
        <div className='cards'>
            <div className='text-center'>
                <img className='portada'  src={paletaSombras} alt="paleta de soimbras"/>
            </div>  
            <div className='contenedor_text'>           
            <h3>PALETA DE SOMBRAS</h3> 
                <p><ul>

                    <li>Sombra de ojos 12 tonos</li> 

                    <li>Incluye pincel aplicador</li> 

                    <li> Marca USHAS</li> 

                    <li>Autorizado MSP</li> </ul></p>
                 
                <Divider/>
                <p>UYU 480</p>
                <Divider/>    
                <div className='botonComprar'>   
                    <BotonComprar/>
                </div>   
            </div>           
        </div>
        <div className='cards'>
            <div className='text-center'>
                <img className='portada'  src={fijadorMaquillaje} alt="fijador de maquillaje"/>
            </div>  
            <div className='contenedor_text'>           
                <h3>Fijador de maquillaje</h3> 
                <p>
                Ayuda a que tu maquillaje dure por más tiempo, dándole una apariencia fresca y radiante, con propiedades naturales. 
                4 diferentes aromas:🧡Vainilla y Coco 💜Floral 💚Pepino 💗Rosas.Presentación de 120ml
                </p>
                    <Divider/>
                    <p>Desde UYU 259 </p>
                    <Divider/>      
                <div className='botonComprar'>   
                    <BotonComprar/>
                </div>   
            </div>           
        </div>

        <div className='cards'>
            <div className='text-center'>
                <img className='portada'  src={mascara2en1} alt="mascara "/>
            </div>  
            <div className='contenedor_text'>           
                <h3>Mascara 2 en 1</h3> 
                <p>
                 <ul>
                     <li>Doble pincel.</li>

                    <li>Color negro.</li> 

                    <li>Marca USHAS.</li> 

                    <li> Autorizado por MSP.</li></ul></p>
                    <Divider/>
                    <p>UYU 150</p>
                    <Divider/>    
                <div className='botonComprar'>   
                    <BotonComprar/>
                </div>           
            </div>           
        </div>

        <div className='cards'>
            <div className='text-center'>
               <Link to="/pagina-del-producto"> <img  className='portada'  src={limpiadorFacialconFormaPulpo} alt="limpiador facial pulpo"/> </Link>
            </div>  
            <div className='contenedor_text'>           
                <h3> <Link to="/pagina-del-producto"> Limpiador facial con forma de pulpo🐙 </Link> </h3> 
                <p>Rapido,eficaz y de facil uso.
                MODO DE USO: 
                Debes umedecerlo antes de usarlo, coloca el jabon facial de tu preferencia, masajea y frota exparciendo la espuma por tu rostro
                
                Tamaño: 5cm x 5.3cm x4cm aprox</p>
                    <Divider/>
                    <p>UYU 200</p>
                    <Divider/>     
                 <div className='botonComprar'>   
                    
                    <BotonComprar/>
                </div>           
            </div>           
        </div>
    
        
    
    
    
    
    
    
    
    
    
    </div>   
    );
}
export default Cards;