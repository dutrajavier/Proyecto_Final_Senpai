import React from 'react';
import '../css/footer.css';
import PagesCatalogo from '../pages/PagesCatalogo';
import { Divider,Icon } from 'semantic-ui-react';

import {
    Link
    } from 'react-router-dom';


function Footer(){
    return(
    
    <div className='footer'>
        <div className='accesible'>
            <div className='navegacion area_nav'>
              <h3>Navegación</h3>
                <ul >
                <li><Link to="/">
                        HOME</Link></li>
                    <li>
                      <Link to="/Catalogo">
                        Catálogo</Link></li>
                    <li>
                    <Link to="/FAQ">
                        FAQ</Link></li>
                            
                    <li><Link to="/miCarrito">
                         Carrito </Link></li>
                </ul>
            </div>
           
            <div className='redes area_redes'>
                <h3 >Nuestras Redes Sociales</h3>
               <ul >
                   <li><a href="https://www.instagram.com/koukla_cosmeticos/"><Icon name='instagram'/>   Instagram</a></li>
                   <li><a href="https://www.facebook.com/KouklaCosmeticos"><Icon name='facebook'/> Facebook</a> </li>
                </ul>
            </div> 
        </div>  
            <Divider/>
            <div className='copyright'>
             <span >Copyright © 2020 Koukla Cosméticos | Design by Javier Dutra | Dutra.javier21@gmail.com</span> 
        </div>
    </div>
    
    );
}

export default Footer;