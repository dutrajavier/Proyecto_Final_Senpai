import React from 'react';
import '../css/cardsCatalogo.css';
import BotonComprar from './BotonComprar';


import { Divider } from 'semantic-ui-react';


function CardsCatalogo(props){
    
    return(
       
        <div className='cardsCatalogo'>

            <div className='Diseniocards'>
                        <div className='text-centerCatalogo'>
                            
                            <img className='portadaCatalogo'  src={props.imgCatalogo} alt={props.nombreProducto}/>
                        </div>  
                        <div className='contenedor_textCatalogo'>           
                            <h3>{props.nombreProducto}</h3> 
                            <p>{props.brDescripcion} </p> 
                            <Divider/>
                            <p>UYU {props.precioProducto}</p> 
                            <Divider/> 
                            <div className='botonComprarCatalogo'>   
                                <BotonComprar agreProducto={props.agrProducto}/>
                            </div>   
                        </div>           
             </div>

            
                    


        </div>
    )
}

export default CardsCatalogo;