import React from 'react'
import { Table,Icon } from 'semantic-ui-react'
import '../css/styleDetalleProducto.css';
import brochaPez from '../image/img-koukla/brochaPez.jpg'

function TableBody() {
    const [valorCantidad, cambiarCantidad] = React.useState(1);
    return(
        <Table.Body>
      <Table.Row>
        <Table.Cell ><Icon name='cancel' bordered circular link fitted ></Icon> <img src={brochaPez} alt='brocha pez'/> </Table.Cell>
        <Table.Cell> <p>Nombre del producto</p> </Table.Cell>
        <Table.Cell  textAlign='right'> 
                
                <input  id='CantidadProducto' type='number' 
                        aria-label='Cantidad' min='1'  max='15' step='1'
                        value={valorCantidad} onChange={(e) => cambiarCantidad(e.target.value)}> 

                </input>
        </Table.Cell>
        <Table.Cell textAlign='center'>
          SubTotal
        </Table.Cell>
      </Table.Row>
     
     
    </Table.Body>
    )
}
export default TableBody;