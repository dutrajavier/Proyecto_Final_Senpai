import React from 'react'
import '../css/styleTablaTotal.css'
import { Table } from 'semantic-ui-react'
import BotonFinalizarCompra from './BotonFinalizarCompra'

function DetalleTotal () {
    return(
        <div className='tableTotal'> 
            <Table  size='large'>
                <Table.Header >
                <Table.Row>
                    <Table.HeaderCell colSpan='2' textAlign='center'>Total: </Table.HeaderCell>
                    
                    </Table.Row>
                </Table.Header>

                <Table.Body>
                    <Table.Row>
                        <Table.Cell>Sub Total:</Table.Cell>
                        <Table.Cell>precio sub total</Table.Cell>
                    </Table.Row>
                    <Table.Row>
                        <Table.Cell> Total:</Table.Cell>
                        <Table.Cell>precio total</Table.Cell>
                    </Table.Row>
                    <Table.Row >
                        <Table.Cell colSpan='2' textAlign='center' > <BotonFinalizarCompra/></Table.Cell>
                        
                    </Table.Row>
                
                </Table.Body>

            </Table>
        </div>      
)
}
export default DetalleTotal;
