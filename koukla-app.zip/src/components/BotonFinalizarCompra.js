import React from 'react';
import {Button} from 'semantic-ui-react';


function BotonFinalizarCompra(){
    return(
        <Button color='pink'  >
            <Button.Content style={{textAlign: "center"}} visible>Finalizar Compra</Button.Content>
            
        </Button>
    );
}

export default BotonFinalizarCompra;