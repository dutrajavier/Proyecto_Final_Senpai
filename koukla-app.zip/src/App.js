import React from 'react';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';

import PagesHome from './pages/PageHome';
import PagesCatalogo from './pages/PagesCatalogo';
import PregFrecuentes from './pages/PregFrecuentes';
import PaginaDelProducto from './pages/PaginaDelProducto';
import PageCarrito from './pages/PageCarrito';

import {BrowserRouter,
  Switch,
  Route} from 'react-router-dom';




/*PREGUNTAS:
- 
- carousel boostrap, semantic o como hacerlo?
-nav semantic o boostrap
- como hacer carrito?

*/ 

function App() {

     const [productos,cambiarProductos] = React.useState(0)
     function sumarProducto(){
          cambiarProductos(productos + 1);
     }

     


  return (
    
    <BrowserRouter>
    <div>
      <Header productos={productos}/>
        
            <Switch>
                <Route exact path="/">
                     <PagesHome/>
                </Route>
                <Route path="/Catalogo">
                     <PagesCatalogo agregarProducto={sumarProducto} />
                </Route>
                <Route path="/FAQ">
                     <PregFrecuentes />
                </Route>
                <Route path="/pagina-del-producto">
                     <PaginaDelProducto />
                </Route>
                <Route path="/miCarrito">
                     <PageCarrito />
                </Route>
                
          
            </Switch>
            
      <Footer/>
  </div>
  </BrowserRouter>
  );
}

export default App;
