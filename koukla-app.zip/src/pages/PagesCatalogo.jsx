import React from 'react';
import '../css/stylePagesCatalogo.css';
import CardsCatalogo from '../components/CardsCatalogo';

function PagesCatalogo(props){
  
    const [productoLista,cambiarProductoLista ] = React.useState([0])
    

   

 React.useEffect(function(){
     fetch('http://localhost:4000/productos')
     .then(function(respuesta){
          return respuesta.json();
     })
     .then(function(respuestaJSON){
         console.log(respuestaJSON);
        
        cambiarProductoLista(respuestaJSON)
         
     })
     .catch(function(error){
        console.error("todo mal");
     })
},[]);
    
var imprimirLista = productoLista.map(function(producto) {
     return <CardsCatalogo key={producto.id} imgCatalogo={producto.img}
      nombreProducto={producto.nombre} 
   brDescripcion={producto.breveDescripcion} precioProducto={producto.precio} />
    
})
   
    return(
    <div className='pageCatalogo'>
        
       
      {imprimirLista}   
            
    </div>
    )
}


export default PagesCatalogo;