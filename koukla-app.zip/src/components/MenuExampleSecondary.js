import React, { Component } from 'react'
import { Input, Menu,Dropdown } from 'semantic-ui-react'

import {
  Link
  } from 'react-router-dom';

export default class MenuExampleSecondary extends Component  {
  state = { activeItem: 'home' }

  handleItemClick = (e, { name }) => this.setState({ activeItem: name })

  render() {
    const { activeItem } = this.state

    return (
       <Menu secondary >
        
        <Menu.Item as={Link} position='right'
          name='home' to='/'
          active={activeItem === 'home'}
          onClick={this.handleItemClick}
        />
        
        <Menu.Item as={Link}
          name='catálogo' to='/Catalogo'
          active={activeItem === 'catálogo'}
          onClick={this.handleItemClick}
        />
        <Dropdown item text='Categorías'>
          <Dropdown.Menu>
            <Dropdown.Header></Dropdown.Header>
            <Dropdown.Item>LABIALES</Dropdown.Item>
            <Dropdown.Item>SOMBRAS</Dropdown.Item>
            <Dropdown.Item>RIMEL</Dropdown.Item>
            <Dropdown.Item>PESTAÑAS</Dropdown.Item>
            <Dropdown.Item>CUIDADO FACIAL</Dropdown.Item>
            <Dropdown.Item>ALHAJEROS</Dropdown.Item>
            <Dropdown.Item>DELINEADORES</Dropdown.Item>
            <Dropdown.Item>BROCHAS</Dropdown.Item>
            <Dropdown.Item>ILUMINADOR </Dropdown.Item>
            <Dropdown.Item>ESMALTES </Dropdown.Item>
           
          </Dropdown.Menu>
        </Dropdown>
        <Menu.Item as={Link}
          name='PreguntasFrecuentes' to='/FAQ'
          active={activeItem === 'PreguntasFrecuentes'}
          onClick={this.handleItemClick}
        />
          <Menu.Item>
          <Input
            icon={{ name: 'search', circular: true, link: true  }}
            placeholder='Buscar...'
          />
          </Menu.Item>
          <Menu.Item  as={Link}
          name='miCarrito'  icon={{name:'shop',circular:true , link: true, }} to="/miCarrito"
          active={activeItem === 'miCarrito'} 
          onClick={this.handleItemClick}
          />
          <Menu.Item  
          name={this.props.productos}  
          
          />
        
      </Menu>
    )
  }
}