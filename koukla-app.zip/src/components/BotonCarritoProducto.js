import React from 'react';
import {Button,Icon} from 'semantic-ui-react';


function BotonCarritoProducto(){
    return(
        <Button color='pink' animated='vertical' >
            <Button.Content style={{textAlign: "center"}} visible>Añadir a mi carrito</Button.Content>
            <Button.Content hidden>
            <Icon name='shop' />
            </Button.Content>
        </Button>
    );
}

export default BotonCarritoProducto;
