import React from 'react';
import logo from '../image/logo.jpg'
import '../css/header.css'; 
import MenuExampleSecondary from './MenuExampleSecondary';

import {
  Link
  } from 'react-router-dom';


function Header(props){
    return(
  <div className='header-container'>     
      <Link to="/"> <img className='logo' src={logo} alt="logo-koukla"/>  </Link>
      <MenuExampleSecondary productos={props.productos}/>



</div>  
  );
}

export default Header;
