import React, { Component } from 'react';

import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import '../css/styleCarousel.css';
import { Carousel } from 'react-responsive-carousel';

import rimelUshas from '../image/img-koukla/rimelUshas.PNG'
import iluminadorColoresOpacos from '../image/img-koukla/iluminadorColoresOpacos.PNG'
import mascarillaNegra from '../image/img-koukla/mascarillaNegra.PNG'
import mascaraDePestañas from '../image/img-koukla/mascaraDePestañas.PNG'
import limpiadorBrocha from '../image/img-koukla/limpiadorBrocha.jpg'
import brochasFlyer from '../image/img-koukla/brochasFlyer.png'


class DemoCarousel extends Component {
    render() {
        return (
            <Carousel>
                <div>
                    <img className="img-carousel" src={rimelUshas} alt=' set de articulos ushas' />
                    <p className="legend">Kit Eye Candy</p>
                </div>
                <div>
                    <img className="img-carousel" src={brochasFlyer} alt='brochas' />
                    <p className="legend">Stock de BROCHAS</p>
                </div>
                <div>
                    <img className="img-carousel" src={mascarillaNegra} alt='labiales mate 4 colores' />
                    <p className="legend">Mascara negra Peel Off </p>
                </div>
                <div>
                    <img className="img-carousel" src={iluminadorColoresOpacos} alt='sombra' />
                    <p className="legend">Iluminador USHAS</p>
                </div>
                <div>
                    <img className="img-carousel" src={mascaraDePestañas} alt='mascara para pestañas' />
                    <p className="legend">Mascara de pestañas extra volúmen USHAS</p>
                </div>
                <div>
                    <img className="img-carousel" src={limpiadorBrocha} alt='limpiador para brochas' />
                    <p className="legend">Limpiador para brochas</p>
                </div>
            </Carousel>
        );
    }
}
 
export default DemoCarousel;