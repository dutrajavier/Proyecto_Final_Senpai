import React from 'react';
import {Button,Icon} from 'semantic-ui-react';


function BotonComprar(props){
    return(
        <Button animated='vertical' onClick={props.agreProducto} >
            <Button.Content style={{textAlign: "center"}} visible >Añadir a mi carrito</Button.Content>
            <Button.Content hidden>
            <Icon name='shop' />
            </Button.Content>
        </Button>
    );
}

export default BotonComprar;
