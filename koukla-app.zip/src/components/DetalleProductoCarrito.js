import React from 'react'
import { Table } from 'semantic-ui-react'
import TableBody from './TableBody'
import '../css/styleDetalleProducto.css';


function DetalleProductosCarrito () {

    return(
<div className='tableDetallesProductos'>    
  <Table fixed>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell textAlign='center' >Producto</Table.HeaderCell>
        <Table.HeaderCell ></Table.HeaderCell>
        <Table.HeaderCell textAlign='right'>Cantidad</Table.HeaderCell>
        <Table.HeaderCell textAlign='center' className='columnChica'>Subtotal</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <TableBody/>
    

  </Table>
  </div> 
);
}

export default DetalleProductosCarrito;