import React from 'react';

import {Divider} from 'semantic-ui-react';
import Cards from './Cards';

import '../css/main.css';
import DemoCarousel from './CarouselDemo';
function Main(){
    return(
        <div className='contenedor'>
           
            <DemoCarousel/>
            <Divider/>
            <h2>Novedades Irresistibles</h2>
            <Cards/>

            




            <Divider/>
       
        
        </div>
    );
}
export default Main;