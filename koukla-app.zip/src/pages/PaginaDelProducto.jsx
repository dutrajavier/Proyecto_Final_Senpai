import React from 'react';
import limpiadorFacialconFormaPulpo from '../image/img-koukla/limpiadorFacial-conFormaPulpo.jpg'
import '../css/stylePagProducto.css';
import { Divider } from 'semantic-ui-react';

import BotonCarritoProducto from '../components/BotonCarritoProducto';


function PaginaDelProducto(){

const [valorCantidad, cambiarCantidad] = React.useState(1);


    return(
        <div className='paginaProducto' >
            <div className='contenedorProducto'>
                <div className='imgProducto'>
                    <img src={limpiadorFacialconFormaPulpo} alt='limpiador facial pulpo'/>
                    <h2>Descripción</h2>
                    <p>MODO DE USO: Para usar adecuadamente tu cepillo facial, necesitas mojarlo un poco antes de empezar. 
                        En la parte de enmedio del ceipillo facial coloca el jabon facial de tu preferencia, justo dentro de la esponja interna.
                        Trata de darule un rudoi masaje al cepillo para que la esponja que esta dentro, el jabon y el agua hagan su trabajo 
                        para que nos traigan la maravilla de la limpieza: la espuma. Frota la espuma sobre tu cara con las pequeñas cerdas del cepillo para lipiarla.
                        Al finalizar, trata de limpiar muy bien la esponja que esta adentro del cepillo, 
                        porque de lo contrario pueden crearse hongos. Cambiala minimo cada 3 meses. 
                        Tamaño: 5cm x 5.3cm x4cm aprox
                    </p>
                </div>
                
                <article className="info">
                    <h1>Limpiador facial con forma de pulpo🐙</h1>
                    <span>$UYU 200</span>
                    
                    <div className="quantity">
                        <label for='CantidadProducy'>Cantidad:</label>
                        <input  
                        id='CantidadProducto' type='number' 
                        aria-label='Cantidad' min='1'  max='15' step='1'
                        value={valorCantidad} onChange={(e) => cambiarCantidad(e.target.value)}> 

                        </input>
                        
                    </div>
                    <Divider/>
                    <BotonCarritoProducto/>
                </article>
            </div> 


        </div>
    );
}


export default PaginaDelProducto;
