import React from 'react';
import '../css/menu.css'; 
import {Icon} from 'semantic-ui-react' 

function MenuP(){
    return(
   <ul className='menu'>
    <li>HOME</li>
    <li>CATALOGO</li>
    <li>CATEGORIAS</li>
    <li>Preguntas Frecuentes</li>
    <li></li> 
</ul>

    );
}
export default MenuP;