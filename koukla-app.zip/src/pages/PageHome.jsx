
import '../App.css';

import Main from '../components/Main';



/*PREGUNTAS:
- 
- carousel boostrap, semantic o como hacerlo?
-nav semantic o boostrap
- como hacer carrito?

*/ 

function PagesHome() {
  return (
    
    <div className="App">
      
      <Main/>
      
      
      
    </div>
    
  );
}

export default PagesHome;
