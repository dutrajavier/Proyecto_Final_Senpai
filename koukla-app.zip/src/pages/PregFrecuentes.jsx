import react from 'react';
import '../css/stylePregFrecuentes.css';
import React, { Component } from 'react'
import { Accordion, Icon } from 'semantic-ui-react'

export default class PregFrecuentes extends Component {
  state = { activeIndex: 0 }

  handleClick = (e, titleProps) => {
    const { index } = titleProps
    const { activeIndex } = this.state
    const newIndex = activeIndex === index ? -1 : index

    this.setState({ activeIndex: newIndex })
  }

  render() {
    const { activeIndex } = this.state

    return (
      <div className='bodyFAQ'>
           <div className='grilla'>
              <Accordion styled>
                <Accordion.Title
                  active={activeIndex === 0}
                  index={0}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Hacen envíos al interior?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 0}>
                  <p>
                  Si, se realizan envios a todo el pais mediante DAC u otra agencia 
                  de encomiendas que prefieras. El costo del envio quedara a cargo del cliente.
                  </p>
                </Accordion.Content>

                <Accordion.Title
                  active={activeIndex === 1}
                  index={1}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Y en Montevideo?¿Hacen envíos?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 1}>
                  <p>
                    No, por el momento no estamos realizando envios en Montevideo 
                    pero si nos manejamos con puntos de encuentro acordes tanto para el vendedor como el cliente .
                  </p>
                </Accordion.Content>

                <Accordion.Title
                  active={activeIndex === 2}
                  index={2}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Cuánto demora el pedido en armarse?Tienen algun minimo de compra?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 2}>
                  <p>
                    Luego de realizada la compra, actualmente tenemos una demora de 24hrs. 
                    Dependiendo de la demanda en el peor de los casos puede quedar para las siguientes 48hrs.
                    Y no, no tenemos minimos de compra,cualquiera que sea su compra estaremos complacidos de hacersela llegar.
            
                  </p>
                
                </Accordion.Content>

                <Accordion.Title
                  active={activeIndex === 3}
                  index={3}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Los productos tienen cambio por algun desperfecto?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 3}>
                  <p>
                    Todos nuestros productos son cien por ciento confiables pero
                    en caso de que el mismo cuente con algun desperfecto de fabrica el mismo 
                    tendra cambio claramente.
                  </p>
                
                </Accordion.Content>

                <Accordion.Title
                  active={activeIndex === 4}
                  index={4}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Qué metodos de pagos utilizan?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 4}>
                  <p>
                    Al momento trabajamos con efectivo contado en Montevideo tambien deposito mediante tarjeta Mi Dinero o Prex,
                    grio Abitab y tranferencias bancarias.
                  </p>
                
                </Accordion.Content>

                <Accordion.Title
                  active={activeIndex === 5}
                  index={5}
                  onClick={this.handleClick}
                >
                  <Icon name='dropdown' />
                  ¿Tienen local?
                </Accordion.Title>
                <Accordion.Content active={activeIndex === 5}>
                  <p>
                    No, no contamos con local propio al momento pero luego de realizada
                    la compra pueden retirar en nuestro PickUp-center en la zona de La Comercial o coordinación de puntos de encuentro
                  </p>
                
                </Accordion.Content>

                





              </Accordion>
         </div>


   </div>
    )
  }
}