import React from 'react';
import '../css/stylePageCarrito.css'
import DetalleProductosCarrito from '../components/DetalleProductoCarrito';
import DetalleTotal from '../components/DetalleTotal';



function PageCarrito(){
    return(
        <div className='stylePageCarrito'>
            <DetalleProductosCarrito/>
            <DetalleTotal/>
        </div>
    )
}

export default PageCarrito;